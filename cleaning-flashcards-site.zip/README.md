# Cleaning Process Flashcards

Single‑file site. To publish on GitHub Pages:

1. Create a public repo (e.g. `cleaning-flashcards`).
2. Add this `index.html` to the repo root and commit to `main`.
3. Settings → Pages → Source: Deploy from a branch → Branch: `main` / `/ (root)` → Save.
4. Your site will appear at `https://<your-username>.github.io/cleaning-flashcards/`.

Tips:
- Allow pop‑ups for the site so the Print window can open.
- Drag & drop a JSON file to import cards. Press Cmd/Ctrl+S to export JSON.
